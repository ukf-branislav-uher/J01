package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.effect.Glow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polyline;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Group root = new Group();
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 720, 405, Color.BLACK));
        primaryStage.show();

        // TODO: vytvort scenu 720x405
        //  fialove: 129, 190 | 143, 175 | 103, 175 | 143, 225 | 101, 225 | 113, 209
        Polyline fialove = new Polyline(new double[]{
                129, 190,
                143, 175,
                103, 175,
                143, 225,
                101, 225,
                101, 225,
                113, 209
        });
        fialove.setStroke(Color.PURPLE);
        fialove.setStrokeWidth(4);
        fialove.setEffect(new Glow(20));

        Polyline biele1 = new Polyline(new double[]{
                129, 190,
                143, 175,
                103, 175,
                143, 225,
                101, 225,
                101, 225,
                113, 209
        });
        biele1.setStroke(Color.WHITE);
        biele1.setStrokeWidth(2);
        biele1.setEffect(new Glow(0));

        //  zlte: 247, 190 | 261, 190 | 268, 175 | 219, 175 | 242, 225 | 251, 201
        Polyline zlte = new Polyline(new double[]{
                247, 190,
                261, 190,
                268, 175,
                219, 175,
                242, 225,
                251, 201
        });
        zlte.setStroke(Color.YELLOW);
        zlte.setStrokeWidth(4);
        zlte.setEffect(new Glow(20));

        Polyline biele2 = new Polyline(new double[]{
                247, 190,
                261, 190,
                268, 175,
                219, 175,
                242, 225,
                251, 201
        });
        biele2.setStroke(Color.WHITE);
        biele2.setStrokeWidth(2);
        biele2.setEffect(new Glow(0));

        //  cervene: 366, 175 | 340, 225 | 390, 225 | 375, 194
        Polyline cervene = new Polyline(new double[]{
                366, 175,
                340, 225,
                390, 225,
                375, 194
        });
        cervene.setStroke(Color.RED);
        cervene.setStrokeWidth(4);
        cervene.setEffect(new Glow(20));

        Polyline biele3 = new Polyline(new double[]{
                366, 175,
                340, 225,
                390, 225,
                375, 194
        });
        biele3.setStroke(Color.WHITE);
        biele3.setStrokeWidth(2);
        biele3.setEffect(new Glow(0));

        //  zelene: 513, 175 | 460, 175 | 486, 225 | 506, 190
        Polyline zelene = new Polyline(new double[]{
                513, 175,
                460, 175,
                486, 225,
                506, 190
        });
        zelene.setStroke(Color.GREEN);
        zelene.setStrokeWidth(4);
        zelene.setEffect(new Glow(20));

        Polyline biele4 = new Polyline(new double[]{
                513, 175,
                460, 175,
                486, 225,
                506, 190
        });
        biele4.setStroke(Color.WHITE);
        biele4.setStrokeWidth(2);
        biele4.setEffect(new Glow(0));

        //  modre/tyrkysove: 606, 206 | 591, 206 | 580, 225 | 635, 225 | 607, 175 | 598, 190
        Polyline modre = new Polyline(new double[]{
                606, 206,
                591, 206,
                580, 225,
                635, 225,
                607, 175,
                598, 190
        });
        modre.setStroke(Color.BLUE);
        modre.setStrokeWidth(4);
        modre.setEffect(new Glow(20));

        Polyline biele5 = new Polyline(new double[]{
                606, 206,
                591, 206,
                580, 225,
                635, 225,
                607, 175,
                598, 190
        });
        biele5.setStroke(Color.WHITE);
        biele5.setStrokeWidth(2);
        biele5.setEffect(new Glow(0));

        root.getChildren().addAll(fialove, biele1, zlte, biele2, cervene, biele3, zelene, biele4, modre, biele5);
    }


    public static void main(String[] args) {
        launch(args);
    }
}
