package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Group root = new Group();

        TextField field = new TextField();
        Button button = new Button("Zmen pozadie");
        HBox h= new HBox();
        h.getChildren().addAll(field, button);
        button.setOnAction(e -> {
            int r = 0, g = 0, b = 0;
            List<Character> samohlasky = new ArrayList<>();
            samohlasky.add('a');
            samohlasky.add('e');
            samohlasky.add('i');
            samohlasky.add('o');
            samohlasky.add('u');
            samohlasky.add('y');
            samohlasky.add('á');
            samohlasky.add('é');
            samohlasky.add('í');
            samohlasky.add('ó');
            samohlasky.add('ú');
            samohlasky.add('ý');


            String text = field.getText().toString();
            primaryStage.setTitle(text);
            for (int i = 0; i < text.length(); i++) {
                if (samohlasky.contains(text.charAt(i))) {
                    r++;
                } else {
                    g++;
                }
                b++;
            }

            r = r * 16 % 255;
            g = g * 24 % 255;
            b = b % 25 * 10 % 255;

            primaryStage.getScene().setFill(Color.rgb(r, g, b));
        });

        root.getChildren().addAll(h);
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
